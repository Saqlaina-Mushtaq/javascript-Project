function toggleMenu() {
  const menu = document.getElementById("menu");
  menu.classList.toggle("open");
}
document.addEventListener('DOMContentLoaded', () => {
  const animatedText = document.getElementById('animated-text');
  const words = ['websites', 'design', 'print'];
  let wordIndex = 0;

  // Change text periodically
  setInterval(() => {
    wordIndex = (wordIndex + 1) % words.length;
    animatedText.textContent = words[wordIndex];
  }, 2000);

  // Toggle collapse menu
  const collapseBar = document.querySelector('.collapse-bar');
  const menu = document.querySelector('.menu');

  collapseBar.addEventListener('click', () => {
    menu.style.display = menu.style.display === 'flex' ? 'none' : 'flex';
    menu.style.flexDirection = 'column';
    menu.style.position = 'absolute';
    menu.style.top = '50px';
    menu.style.right = '20px';
    menu.style.background = '#000';
    menu.style.padding = '10px';
    menu.style.borderRadius = '10px';
  });
});

document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll(".slide")
  const dots = document.querySelectorAll(".dot")
  const prevButton = document.querySelector(".nav-button.prev")
  const nextButton = document.querySelector(".nav-button.next")
  let currentSlide = 0
  let autoSlideInterval

  function showSlide(index) {
    slides.forEach((slide, i) => {
      slide.classList.toggle("active", i === index)
    })
    dots.forEach((dot, i) => {
      dot.classList.toggle("active", i === index)
    })
  }

  function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length
    showSlide(currentSlide)
  }

  function prevSlide() {
    currentSlide = (currentSlide - 1 + slides.length) % slides.length
    showSlide(currentSlide)
  }

  function startAutoSlide() {
    autoSlideInterval = setInterval(nextSlide, 5000)
  }

  function stopAutoSlide() {
    clearInterval(autoSlideInterval)
  }

  prevButton.addEventListener("click", () => {
    prevSlide()
    stopAutoSlide()
    startAutoSlide()
  })

  nextButton.addEventListener("click", () => {
    nextSlide()
    stopAutoSlide()
    startAutoSlide()
  })

  dots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
      currentSlide = index
      showSlide(currentSlide)
      stopAutoSlide()
      startAutoSlide()
    })
  })

  const sliderContainer = document.querySelector(".slider-container")
  sliderContainer.addEventListener("mouseenter", stopAutoSlide)
  sliderContainer.addEventListener("mouseleave", startAutoSlide)

  startAutoSlide()
});

