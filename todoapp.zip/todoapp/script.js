document.addEventListener("DOMContentLoaded", () => {
  const todoForm = document.getElementById("todo-form")
  const todoInput = document.getElementById("todo-input")
  const todoList = document.getElementById("todo-list")

  const todos = JSON.parse(localStorage.getItem("todos")) || []

  function saveTodos() {
    localStorage.setItem("todos", JSON.stringify(todos))
  }

  function renderTodos() {
    todoList.innerHTML = ""
    todos.sort((a, b) => {
      if (a.marked === b.marked) {
        return 0
      }
      return a.marked ? -1 : 1
    })

    todos.forEach((todo, index) => {
      const li = document.createElement("li")
      li.className = `todo-item ${todo.marked ? "marked" : ""}`
      li.innerHTML = `
                <span class="mark-star">&#9733;</span>
                <input type="checkbox" ${todo.completed ? "checked" : ""}>
                <span class="todo-text">${todo.text}</span>
                <button class="delete-button">Delete</button>
            `

      const markStar = li.querySelector(".mark-star")
      markStar.addEventListener("click", () => {
        todos[index].marked = !todos[index].marked
        saveTodos()
        renderTodos()
      })

      const checkbox = li.querySelector('input[type="checkbox"]')
      checkbox.addEventListener("change", () => {
        todos[index].completed = checkbox.checked
        saveTodos()
      })

      const deleteButton = li.querySelector(".delete-button")
      deleteButton.addEventListener("click", () => {
        todos.splice(index, 1)
        saveTodos()
        renderTodos()
      })

      todoList.appendChild(li)
    })
  }

  todoForm.addEventListener("submit", (e) => {
    e.preventDefault()
    const todoText = todoInput.value.trim()
    if (todoText) {
      todos.push({ text: todoText, completed: false, marked: false })
      saveTodos()
      renderTodos()
      todoInput.value = ""
    }
  })

  renderTodos()
})

