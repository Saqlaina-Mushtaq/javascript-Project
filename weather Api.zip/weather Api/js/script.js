async function getWeather() {
  const location = document.getElementById("location").value;
  const apiKey = "6cf812ecfc254175ac4111435253101";
  const url = `http://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${location}&aqi=yes`;

  

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.error) {
      document.getElementById(
        "weather-info"
      ).innerHTML = `<p style="color:red;">${data.error.message}</p>`;
      return;
    }

    document.getElementById("weather-info").innerHTML = `
                    <h3>${data.location.name}, ${data.location.country}</h3>
                    <p>Temperature: ${data.current.temp_c}°C</p>
                    <p>Condition: ${data.current.condition.text}</p>
                    <p>Humidity: ${data.current.humidity}%</p>
                    <p>Wind Speed: ${data.current.wind_kph} km/h</p>
                    <img src="${data.current.condition.icon}" alt="Weather Icon">
                `;
  } catch (error) {
    document.getElementById(
      "weather-info"
    ).innerHTML = `<p style="color:red;">Error fetching weather data.</p>`;
  }
}
